package fitness.app.myfitness;

public class UserInfo {
    private String PersonWeight;
    private String PersonHeight;
    private String PersonAge;
    private String CaloryIntake;
    private String GoalWeight;
    private String GoalCalory;
    private String Gender;
    private String System;
    private String Status;
    private String GoalHeight;

    public UserInfo(String personWeight, String personHeight, String personAge, String caloryIntake, String goalWeight, String goalCalory,String gender, String system,String goalHeight ) {
        PersonWeight = personWeight;
        PersonHeight = personHeight;
        PersonAge = personAge;
        CaloryIntake = caloryIntake;
        GoalWeight = goalWeight;
        GoalCalory = goalCalory;
        Gender = gender;
        System = system;
        GoalHeight = goalHeight;
    }
    public UserInfo(String status){
        Status = status;
    }
    public UserInfo(){

    }

    public String getPersonWeight() {
        return PersonWeight;
    }

    public void setPersonWeight(String personWeight) {
        PersonWeight = personWeight;
    }

    public String getPersonHeight() {
        return PersonHeight;
    }

    public void setPersonHeight(String personHeight) {
        PersonHeight = personHeight;
    }

    public String getPersonAge() {
        return PersonAge;
    }

    public void setPersonAge(String personAge) {
        PersonAge = personAge;
    }

    public String getCaloryIntake() {
        return CaloryIntake;
    }

    public void setCaloryIntake(String caloryIntake) {
        CaloryIntake = caloryIntake;
    }

    public String getGoalWeight() {
        return GoalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        GoalWeight = goalWeight;
    }

    public String getGoalCalory() {
        return GoalCalory;
    }

    public void setGoalCalory(String goalCalory) {
        GoalCalory = goalCalory;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) { Gender = gender; }

    public String getSystem() {
        return System;
    }

    public void setSystem(String system) { System = system; }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) { Status = status; }

    public String getGoalHeight() {
        return GoalHeight;
    }

    public void setGoalHeight(String goalHeight) {
        GoalHeight = goalHeight;
    }
}
