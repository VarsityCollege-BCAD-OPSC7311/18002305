package fitness.app.myfitness;

public class DailyWeight {
    private String CurrentWeight;
    private String CurrentDate;

    public DailyWeight(String currentWeight,String currentDate) {
        CurrentWeight = currentWeight;
        CurrentDate = currentDate;
    }

    public String getCurrentWeight() {
        return CurrentWeight;
    }

    public void setCurrentWeight(String currentWeight) {
        CurrentWeight = currentWeight;
    }
    public String getCurrentDate() {
        return CurrentDate;
    }

    public void setCurrentDate(String currentDate) {
        CurrentDate = currentDate;
    }
}
