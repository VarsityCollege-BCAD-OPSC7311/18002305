package fitness.app.myfitness.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import fitness.app.myfitness.Models.ImageModel;
import fitness.app.myfitness.R;

public class CloudImagesAdapter extends RecyclerView.Adapter<CloudImagesAdapter.MyViewHolder> {
    Context context;
    List<ImageModel> photoList= new ArrayList<>();
    ImageModel imageModel;

    public CloudImagesAdapter(){}

    public CloudImagesAdapter(Context context, List<ImageModel> photoList){
        this.context = context;
        this.photoList = photoList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(context).inflate(R.layout.picture_items,parent,false);
        return new MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        ImageModel imageModel = photoList.get(position);

        holder.cloudImageName.setText(imageModel.getImageName());

        Picasso.get().load(imageModel.getImageUrl()).fit().centerCrop().into(holder.cloudImage);
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        ImageView cloudImage;
        TextView cloudImageName;
        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);

            cloudImage = itemView.findViewById(R.id.adapter_image);
            cloudImageName = itemView.findViewById(R.id.adapter_imageName);
        }
    }
}
