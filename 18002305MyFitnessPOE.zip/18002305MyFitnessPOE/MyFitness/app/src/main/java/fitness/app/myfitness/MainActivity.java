package fitness.app.myfitness;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import fitness.app.myfitness.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    double d1,d2,d3,d4,d5,d6;
    int var1,var2,var3,var4,var5,var6;
    String Gender,System,save,genSave;
    Switch Convert;
    TextView starterWeight,currentHeight,AgeDis,GenderDis,caloryIntake,goalWeight,goalCalInt,detWeight,detHeight,detGWeight,dayWeight,detGHeight,goalHeight;
    CalendarView currentDate;
    EditText email, password, txtOther,Weight,Height,age,Calory,GWeight,GCalory,currentWeight,GHeight;
    Button signIn, createNew, signOut,Add,Profile,dailyFood,dailyWeight,Details,cancel,addWeight,cancelWeight,returnUser,edit,chartBack,Chart;
    RadioButton Male,Female,Other;
    private FirebaseAuth mAuth;
    FirebaseUser currentUser;
    CardView loginCardView,detailsCardView,optionsCardView,dailyCardView,profileCardView,chartCardView;
    FirebaseDatabase database = FirebaseDatabase.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        email = findViewById(R.id.inpEmail);
        password = findViewById(R.id.inpPassword);
        signIn = findViewById(R.id.btnLogin);
        createNew = findViewById(R.id.btnRegister);
        currentUser = mAuth.getCurrentUser();
        loginCardView = findViewById(R.id.cardview_login);
        detailsCardView = findViewById(R.id.cardview_Details);
        signOut = findViewById(R.id.btnSignOut);
        Male = findViewById(R.id.radMale);
        Female = findViewById(R.id.radFemale);
        Other = findViewById(R.id.radOther);
        txtOther = findViewById(R.id.inpOther);
        Add = findViewById(R.id.btnAdd);
        Weight = findViewById(R.id.numWeight);
        Height =findViewById(R.id.numHeight);
        age =findViewById(R.id.numAge);
        Calory =findViewById(R.id.numCalory);
        GWeight =findViewById(R.id.numGWeight);
        GCalory =findViewById(R.id.numGCalory);
        optionsCardView = findViewById(R.id.cardview_Options);
        Profile = findViewById(R.id.btnProfile);
        dailyFood = findViewById(R.id.btnDailyFood);
        dailyWeight = findViewById(R.id.btnDailyWeight);
        Details = findViewById(R.id.btnDetails);
        cancel = findViewById(R.id.btnCancel);
        currentWeight = findViewById(R.id.numTodayWeight);
        currentDate = findViewById(R.id.dateCurrent);
        addWeight = findViewById(R.id.btnAddDaily);
        cancelWeight = findViewById(R.id.btnCancelDaily);
        dailyCardView = findViewById(R.id.cardview_Daily);
        starterWeight = findViewById(R.id.txtWeightDis);
        currentHeight = findViewById(R.id.txtHeightDis);
        AgeDis = findViewById(R.id.txtAgeDis);
        GenderDis = findViewById(R.id.txtGenderDis);
        caloryIntake = findViewById(R.id.txtCaloryIntake);
        goalWeight = findViewById(R.id.txtGoalWeightDis);
        goalCalInt = findViewById(R.id.txtGoalCaloryIntakeDis);
        profileCardView = findViewById(R.id.cardview_Profile);
        edit =findViewById(R.id.btnEdit);
        returnUser =findViewById(R.id.btnReturn);
        Convert = findViewById(R.id.swConvert);
        dayWeight= findViewById(R.id.txtKilogram);
        detWeight= findViewById(R.id.lblWeight);
        detHeight = findViewById(R.id.lblHeight);
        detGWeight = findViewById(R.id.lblGWeight);
        chartBack=findViewById(R.id.btnChartBack);
        GHeight = findViewById(R.id.numGHeight);
        detGHeight = findViewById(R.id.lblGHeight);
        goalHeight = findViewById(R.id.txtGoalHeightDis);
        chartCardView = findViewById(R.id.cardview_Chart);
        Chart = findViewById(R.id.btnChart);



        detailsCardView.setVisibility(View.GONE);
        dailyCardView.setVisibility(View.GONE);
        currentDate.setVisibility(View.GONE);
        profileCardView.setVisibility(View.GONE);
        chartCardView.setVisibility(View.GONE);
        Gender ="Male";
        System = "Metric";
        if (currentUser!=null)
        {
            loginCardView.setVisibility(View.GONE);
        }
        else
        {
            loginCardView.setVisibility(View.VISIBLE);
            signOut.setVisibility(View.GONE);
            optionsCardView.setVisibility(View.GONE);
        }

        createNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String enteredEmail = email.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();
                mAuth.createUserWithEmailAndPassword(enteredEmail, enteredPassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this, "User "
                                            + Objects.requireNonNull(mAuth.getCurrentUser()).getEmail() + "Successful", Toast.LENGTH_SHORT).show();
                                }
                                else {
                                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredEmail = email.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();

                mAuth.signInWithEmailAndPassword(enteredEmail,enteredPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this, "Logged in " +
                                    Objects.requireNonNull(mAuth.getCurrentUser()).getEmail()+" successfully", Toast.LENGTH_SHORT).show();
                            loginCardView.setVisibility(View.GONE);
                            signOut.setVisibility(View.VISIBLE);

                            optionsCardView.setVisibility(View.VISIBLE);

                        }

                        else
                        {
                            Toast.makeText(MainActivity.this, "Woops you hit a boo boo", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e)
                    {
                        Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Toast.makeText(MainActivity.this, "GoodBye", Toast.LENGTH_SHORT).show();
                loginCardView.setVisibility(View.VISIBLE);
                signOut.setVisibility(View.GONE);
                detailsCardView.setVisibility(View.GONE);
                optionsCardView.setVisibility(View.GONE);
                dailyCardView.setVisibility(View.GONE);
                profileCardView.setVisibility(View.GONE);
                chartCardView.setVisibility(View.GONE);
            }
        });
        Male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Male.isChecked())
                {
                    txtOther.setEnabled(false);
                    Gender ="Male";
                    Female.setChecked(false);
                    Other.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });
        Female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Female.isChecked())
                {
                    txtOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Other.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });
        Other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Other.isChecked())
                {
                    txtOther.setEnabled(true);
                    Gender = txtOther.getText().toString();
                    Female.setChecked(false);
                    Male.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });
        Details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailsCardView.setVisibility(View.VISIBLE);
                optionsCardView.setVisibility(View.GONE);

                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserInfo info = new UserInfo();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        info = snapshot.getValue(UserInfo.class);
                        if(snapshot.exists()) {
                            Weight.setText(info.getPersonWeight());
                            Height.setText(info.getPersonHeight());
                            age.setText(info.getPersonAge());
                            Calory.setText(info.getCaloryIntake());
                            GWeight.setText(info.getGoalWeight());
                            GCalory.setText(info.getGoalCalory());
                            GHeight.setText(info.getGoalHeight());
                            if(info.getSystem() == null)
                            {
                                System = "Metric";
                            }
                            else
                            {
                                System = info.getSystem();
                            }

                            if(info.getGender() == null)
                            {
                                genSave = "Male";
                            }
                            else
                                {
                                    genSave = info.getGender();
                                }

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                });

                if(System.equals("Metric"))
                {
                    Convert.setChecked(false);
                    Convert.setText(System);
                    detWeight.setText("Kg");
                    detHeight.setText("cm");
                    detGWeight.setText("Kg");
                    detGHeight.setText("cm");
                }
                else if (System.equals("Imperial"))
                {
                    Convert.setChecked(true);
                    Convert.setText(System);
                    detWeight.setText("lb");
                    detHeight.setText("Inches");
                    detGWeight.setText("lb");
                    detGHeight.setText("Inches");
                }
                else
                    {
                        Toast.makeText(MainActivity.this, System, Toast.LENGTH_SHORT).show();
                    }

                if(genSave.equals("Male")){
                    txtOther.setEnabled(false);
                    Gender ="Male";
                    Male.setChecked(true);
                    Female.setChecked(false);
                    Other.setChecked(false);
                }
                else if(genSave.equals("Female")){
                    txtOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Female.setChecked(true);
                    Other.setChecked(false);
                }
                else {
                    txtOther.setEnabled(true);
                    Gender = genSave;
                    txtOther.setText(Gender);
                    Male.setChecked(false);
                    Female.setChecked(false);
                    Other.setChecked(true);
                }

            }
        });
        edit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                detailsCardView.setVisibility(View.VISIBLE);
                profileCardView.setVisibility(View.GONE);
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserInfo info = new UserInfo();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        info = snapshot.getValue(UserInfo.class);
                        if(snapshot.exists()) {
                            Weight.setText(info.getPersonWeight());
                            Height.setText(info.getPersonHeight());
                            age.setText(info.getPersonAge());
                            Calory.setText(info.getCaloryIntake());
                            GWeight.setText(info.getGoalWeight());
                            GCalory.setText(info.getGoalCalory());
                            GHeight.setText(info.getGoalHeight());
                            if(info.getSystem() == null)
                            {
                                System = "Metric";
                            }
                            else
                            {
                                System = info.getSystem();
                            }
                            if(info.getGender() == null)
                            {
                                genSave = "Male";
                            }
                            else
                            {
                                genSave = info.getGender();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
                if(System.equals("Metric"))
                {
                    Convert.setChecked(false);
                    Convert.setText(System);
                    detWeight.setText("Kg");
                    detHeight.setText("cm");
                    detGWeight.setText("Kg");
                    detGHeight.setText("cm");
                }
                else if (System.equals("Imperial"))
                {
                    Convert.setChecked(true);
                    Convert.setText(System);
                    detWeight.setText("lb");
                    detHeight.setText("Inches");
                    detGWeight.setText("lb");
                    detGHeight.setText("Inches");
                }
                if(genSave.equals("Male")){
                    txtOther.setEnabled(false);
                    Gender ="Male";
                    Male.setChecked(true);
                    Female.setChecked(false);
                    Other.setChecked(false);
                }
                else if(genSave.equals("Female")){
                    txtOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Female.setChecked(true);
                    Other.setChecked(false);
                }
                else {
                    txtOther.setEnabled(true);
                    Gender = genSave;
                    txtOther.setText(Gender);
                    Male.setChecked(false);
                    Female.setChecked(false);
                    Other.setChecked(true);
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                detailsCardView.setVisibility(View.GONE);
                optionsCardView.setVisibility(View.VISIBLE);

            }
        });
        dailyFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Welcome to photo mode", Toast.LENGTH_SHORT).show();
                Intent openImage = new Intent(getApplicationContext(),CloudPics.class);
                startActivity(openImage);
            }
        });
        dailyWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dailyCardView.setVisibility(View.VISIBLE);
                optionsCardView.setVisibility(View.GONE);
            }
        });
        cancelWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dailyCardView.setVisibility(View.GONE);
                optionsCardView.setVisibility(View.VISIBLE);
            }
        });
        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat date = new SimpleDateFormat("dd MM yyyy");
                SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy");
                String curWeight = currentWeight.getText().toString();
                String curDate = date.format(new Date(currentDate.getDate()));
                String curDateStore = date2.format(new Date(currentDate.getDate()));
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                DailyWeight dailyWeight = new DailyWeight(curWeight,curDateStore);
                if(curWeight.isEmpty() )
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    refUser.child("Daily weight").child(curDate).setValue(dailyWeight);
                    Toast.makeText(MainActivity.this, "Stored weight " + curWeight + "Kg on: " + curDateStore, Toast.LENGTH_SHORT).show();
                    dailyCardView.setVisibility(View.GONE);
                    optionsCardView.setVisibility(View.VISIBLE);
                }
            }
        });
        chartBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.VISIBLE);
                chartCardView.setVisibility(View.GONE);
            }
        });
        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                optionsCardView.setVisibility(View.GONE);
                profileCardView.setVisibility(View.VISIBLE);

                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserInfo info = new UserInfo();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        info = snapshot.getValue(UserInfo.class);
                        if(snapshot.exists()) {

                            d1 =Double.parseDouble(info.getPersonWeight());
                            var1 = (int)d1;
                            d2 =Double.parseDouble(info.getCaloryIntake());
                            var2 = (int)d2;
                            d3 =Double.parseDouble(info.getPersonHeight());
                            var3 = (int)d3;
                            d4 =Double.parseDouble(info.getGoalWeight());
                            var4 = (int)d4;
                            d5 =Double.parseDouble(info.getGoalCalory());
                            var5 = (int)d5;
                            d6 =Double.parseDouble(info.getGoalHeight());
                            var6 = (int)d6;

                            BarChart chart = findViewById(R.id.chart);
                            BarData data = new BarData(getXAxisValues(), getDataSet());
                            chart.setData(data);
                            chart.setDescription("My Chart");
                            chart.animateXY(2000, 2000);
                            chart.invalidate();

                            if(System .equals("Metric")) {
                                starterWeight.setText("Starter Weight: " + info.getPersonWeight() + "Kg");
                                currentHeight.setText("Height: " + info.getPersonHeight() + "cm");
                                AgeDis.setText("Age: " + info.getPersonAge());
                                GenderDis.setText("Gender: " + info.getGender());
                                caloryIntake.setText("Calory Intake: " + info.getCaloryIntake() + " Calories");
                                goalWeight.setText("Goal Weight: " + info.getGoalWeight() + "Kg");
                                goalCalInt.setText("Goal Calory Intake: " + info.getGoalCalory() + " Calories");
                                goalHeight.setText("Goal Height: " + info.getGoalHeight() + " cm");
                            }
                           else if(System.equals("Imperial") ) {
                                starterWeight.setText("Starter Weight: " + info.getPersonWeight() + "lb");
                                currentHeight.setText("Height: " + info.getPersonHeight() + " Inches");
                                AgeDis.setText("Age: " + info.getPersonAge());
                                GenderDis.setText("Gender: " + info.getGender());
                                caloryIntake.setText("Calory Intake: " + info.getCaloryIntake() + " Calories");
                                goalWeight.setText("Goal Weight: " + info.getGoalWeight() + "lb");
                                goalCalInt.setText("Goal Calory Intake: " + info.getGoalCalory() + " Calories");
                                goalHeight.setText("Goal Height: " + info.getGoalHeight() + " Inches");
                            }
                           else
                               {
                                   Toast.makeText(MainActivity.this, System, Toast.LENGTH_SHORT).show();
                               }
                        }
                        else{

                            starterWeight.setText("Starter Weight: no Value Entered" );
                            currentHeight.setText("Height: no Value Entered ");
                            AgeDis.setText("Age: no Value Entered " );
                            GenderDis.setText("Gender: no Value Entered " );
                            caloryIntake.setText("Calory Intake: no Value Entered ");
                            goalWeight.setText("Goal Weight: no Value Entered " );
                            goalCalInt.setText("Goal Calory Intake: no Value Entered ");
                            goalHeight.setText("Goal Height: no Value Entered ");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        Chart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.GONE);
                chartCardView.setVisibility(View.VISIBLE);
            }
        });
        returnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                optionsCardView.setVisibility(View.VISIBLE);
                profileCardView.setVisibility(View.GONE);
            }
        });
        Convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!Convert.isChecked()){
                    System = "Metric";
                    Convert.setText(System);
                    String metricWeight=Weight.getText().toString().trim();
                    String metricHeight=Height.getText().toString().trim();
                    String metricGWeight=GWeight.getText().toString().trim();
                    String metricGHeight = GHeight.getText().toString().trim();
                    if(!metricWeight.isEmpty() && !metricHeight.isEmpty() && !metricGWeight.isEmpty()) {
                        Weight.setText(String.valueOf(Double.parseDouble(metricWeight) / 2.20462));
                        Height.setText(String.valueOf(Double.parseDouble(metricHeight) / 0.3937));
                        GWeight.setText(String.valueOf(Double.parseDouble(metricGWeight) / 2.20462));
                        GHeight.setText(String.valueOf(Double.parseDouble(metricGHeight) / 0.3937));
                    }
                    detWeight.setText("Kg");
                    detHeight.setText("cm");
                    detGWeight.setText("Kg");
                    detGHeight.setText("cm");
                }
                else if(Convert.isChecked()){
                    System = "Imperial";
                    Convert.setText(System);
                    String imperialWeight=Weight.getText().toString().trim();
                    String imperialHeight=Height.getText().toString().trim();
                    String imperialGWeight=GWeight.getText().toString().trim();
                    String imperialGHeight = GHeight.getText().toString().trim();
                    if(!imperialWeight.isEmpty() && !imperialHeight.isEmpty() && !imperialGWeight.isEmpty()) {
                        Weight.setText(String.valueOf(Double.parseDouble(imperialWeight) * 2.20462));
                        Height.setText(String.valueOf(Double.parseDouble(imperialHeight) * 0.3937));
                        GWeight.setText(String.valueOf(Double.parseDouble(imperialGWeight) * 2.20462));
                        GHeight.setText(String.valueOf(Double.parseDouble(imperialGHeight) * 0.3937));
                    }
                    detWeight.setText("lb");
                    detHeight.setText("Inches");
                    detGWeight.setText("lb");
                    detGHeight.setText("Inches");
                }
            }
        });
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userWeight = Weight.getText().toString().trim();
                String userHeight = Height.getText().toString();
                String userAge = age.getText().toString();
                String userCalory = Calory.getText().toString();
                String userGWeight = GWeight.getText().toString();
                String userGCalory = GCalory.getText().toString();
                String userGHeight = GHeight.getText().toString();
                if(Other.isChecked())
                {
                    Gender = txtOther.getText().toString();
                }
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                UserInfo info = new UserInfo(userWeight, userHeight, userAge, userCalory, userGWeight, userGCalory, Gender,System,userGHeight);

                if(userWeight.isEmpty() || userHeight.isEmpty() || userAge.isEmpty() || userCalory.isEmpty() || userGWeight.isEmpty()||userGCalory.isEmpty()||userGHeight.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                  refUser.child("User Info").setValue(info);
                    Toast.makeText(MainActivity.this, "Your Info has been Added/Updated", Toast.LENGTH_SHORT).show();
                    detailsCardView.setVisibility(View.GONE);
                    optionsCardView.setVisibility(View.VISIBLE);
                }


            }
        });


    }
    @Override
    protected void onStart()
    {
        super.onStart();
        if(currentUser != null)
        {

            Male.setEnabled(true);
            genSave = "Male";
            DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());

            refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                UserInfo info = new UserInfo();
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    info = snapshot.getValue(UserInfo.class);
                    if(snapshot.exists()) {


                        Weight.setText(info.getPersonWeight());
                        Height.setText(info.getPersonHeight());
                        age.setText(info.getPersonAge());
                        Calory.setText(info.getCaloryIntake());
                        GWeight.setText(info.getGoalWeight());
                        GCalory.setText(info.getGoalCalory());
                        GHeight.setText(info.getGoalHeight());
                        if(info.getSystem() == null)
                        {
                            System = "Metric";
                        }
                        else
                        {
                            System = info.getSystem();
                        }
                        if(info.getGender() == null)
                        {
                            genSave = "Male";
                        }
                        else
                        {
                            genSave = info.getGender();
                        }

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }
    private ArrayList getDataSet() {
        ArrayList dataSets = null;

        Toast.makeText(MainActivity.this, Integer.toString(var1), Toast.LENGTH_SHORT).show();
        ArrayList valueSet1 = new ArrayList();
        BarEntry v1e1 = new BarEntry(var1, 0); // Weight
        valueSet1.add(v1e1);
        BarEntry v1e2 = new BarEntry(var2, 1); // Calories
        valueSet1.add(v1e2);
        BarEntry v1e3 = new BarEntry(var3, 2); // Height
        valueSet1.add(v1e3);


        ArrayList valueSet2 = new ArrayList();
        BarEntry v2e1 = new BarEntry(var4, 0); // Weight
        valueSet2.add(v2e1);
        BarEntry v2e2 = new BarEntry(var5, 1); // Calories
        valueSet2.add(v2e2);
        BarEntry v2e3 = new BarEntry(var6, 2); // Height
        valueSet2.add(v2e3);


        BarDataSet barDataSet1 = new BarDataSet(valueSet1, "Current");
        barDataSet1.setColor(Color.rgb(3, 252, 244));
        BarDataSet barDataSet2 = new BarDataSet(valueSet2, "Goal");
        barDataSet2.setColor(Color.rgb(3, 252, 152));

        dataSets = new ArrayList();
        dataSets.add(barDataSet1);
        dataSets.add(barDataSet2);
        return dataSets;
    }

    private ArrayList getXAxisValues() {
        ArrayList xAxis = new ArrayList();
        xAxis.add("Weight");
        xAxis.add("Calories");
        xAxis.add("Height");

        return xAxis;
    }
}
